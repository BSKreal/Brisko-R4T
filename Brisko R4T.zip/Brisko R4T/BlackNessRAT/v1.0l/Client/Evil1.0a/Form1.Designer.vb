﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ComputerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputerInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TraceIPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProcessManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartProcessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseProcessusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetAntivirusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FunnyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FakeMessageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonitorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TurnOnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TurnOffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MouseKeyboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnabledToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisabledToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.RigToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DVDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenDVDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseDVDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.CrasyDVDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CursorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HideToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DesktopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskBarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HideToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.IEControlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangeHomePageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SoundToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MuteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SpeakToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangeBackgroundToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenURLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlockWebSiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CControlToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShutdownToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HibernationToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BSODToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StealerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowsKeyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FpscKeyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MsnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NoIpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SteamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StealAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunVbsScriptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunHtmlScriptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunVbsScriptToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CleanScriptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableProtectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableCMDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableControlPanelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableRegistreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WormFunctionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UsbSpreadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkypeSpreadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DDOSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HttpFlodoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartFloodToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GameFlodoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PortToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UDPFloodToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SynFloodToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.IPGraberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.RemoteDownloadExecuteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DelStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RfrshStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.HideShowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WinToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CountryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CPUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RAMStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VersionStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BuilderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.NoIpUpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConnectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.StopToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.lstClients = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.notify = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ShowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkinCrafter1 = New DMSoft.SkinCrafter()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.notify.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ComputerToolStripMenuItem, Me.FunnyToolStripMenuItem, Me.StealerToolStripMenuItem, Me.RunVbsScriptToolStripMenuItem, Me.DisableProtectionToolStripMenuItem, Me.WormFunctionsToolStripMenuItem, Me.DDOSToolStripMenuItem, Me.ToolStripMenuItem1, Me.RemoteDownloadExecuteToolStripMenuItem, Me.CloseStripMenuItem2, Me.DelStripMenuItem2, Me.RfrshStripMenuItem2, Me.ToolStripSeparator1, Me.HideShowToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(222, 302)
        '
        'ComputerToolStripMenuItem
        '
        Me.ComputerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ComputerInfoToolStripMenuItem, Me.TraceIPToolStripMenuItem, Me.ProcessManagerToolStripMenuItem, Me.GetAntivirusToolStripMenuItem})
        Me.ComputerToolStripMenuItem.Image = CType(resources.GetObject("ComputerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ComputerToolStripMenuItem.Name = "ComputerToolStripMenuItem"
        Me.ComputerToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.ComputerToolStripMenuItem.Text = "Computer"
        '
        'ComputerInfoToolStripMenuItem
        '
        Me.ComputerInfoToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.Sign_Info_icon
        Me.ComputerInfoToolStripMenuItem.Name = "ComputerInfoToolStripMenuItem"
        Me.ComputerInfoToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ComputerInfoToolStripMenuItem.Text = "Computer Info"
        '
        'TraceIPToolStripMenuItem
        '
        Me.TraceIPToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.map_magnify_icon
        Me.TraceIPToolStripMenuItem.Name = "TraceIPToolStripMenuItem"
        Me.TraceIPToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.TraceIPToolStripMenuItem.Text = "IP Tracer"
        '
        'ProcessManagerToolStripMenuItem
        '
        Me.ProcessManagerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartProcessToolStripMenuItem, Me.CloseProcessusToolStripMenuItem})
        Me.ProcessManagerToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.cog
        Me.ProcessManagerToolStripMenuItem.Name = "ProcessManagerToolStripMenuItem"
        Me.ProcessManagerToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ProcessManagerToolStripMenuItem.Text = "Process Manager"
        '
        'StartProcessToolStripMenuItem
        '
        Me.StartProcessToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.cog_add
        Me.StartProcessToolStripMenuItem.Name = "StartProcessToolStripMenuItem"
        Me.StartProcessToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.StartProcessToolStripMenuItem.Text = "Start Process"
        '
        'CloseProcessusToolStripMenuItem
        '
        Me.CloseProcessusToolStripMenuItem.Image = CType(resources.GetObject("CloseProcessusToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseProcessusToolStripMenuItem.Name = "CloseProcessusToolStripMenuItem"
        Me.CloseProcessusToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.CloseProcessusToolStripMenuItem.Text = "Close Process"
        '
        'GetAntivirusToolStripMenuItem
        '
        Me.GetAntivirusToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.icon_security_icon
        Me.GetAntivirusToolStripMenuItem.Name = "GetAntivirusToolStripMenuItem"
        Me.GetAntivirusToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.GetAntivirusToolStripMenuItem.Text = "Get Antivirus "
        '
        'FunnyToolStripMenuItem
        '
        Me.FunnyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FakeMessageToolStripMenuItem, Me.MonitorToolStripMenuItem, Me.MouseKeyboardToolStripMenuItem, Me.DVDToolStripMenuItem, Me.CursorToolStripMenuItem, Me.DesktopToolStripMenuItem, Me.IEControlToolStripMenuItem, Me.SoundToolStripMenuItem, Me.SpeakToolStripMenuItem, Me.ChangeBackgroundToolStripMenuItem, Me.OpenProgramToolStripMenuItem, Me.OpenURLToolStripMenuItem, Me.BlockWebSiteToolStripMenuItem, Me.CControlToolStripMenuItem2, Me.BSODToolStripMenuItem})
        Me.FunnyToolStripMenuItem.Image = CType(resources.GetObject("FunnyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FunnyToolStripMenuItem.Name = "FunnyToolStripMenuItem"
        Me.FunnyToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.FunnyToolStripMenuItem.Text = "Funny"
        '
        'FakeMessageToolStripMenuItem
        '
        Me.FakeMessageToolStripMenuItem.Image = CType(resources.GetObject("FakeMessageToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FakeMessageToolStripMenuItem.Name = "FakeMessageToolStripMenuItem"
        Me.FakeMessageToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.FakeMessageToolStripMenuItem.Text = "Fake Message"
        '
        'MonitorToolStripMenuItem
        '
        Me.MonitorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TurnOnToolStripMenuItem, Me.TurnOffToolStripMenuItem})
        Me.MonitorToolStripMenuItem.Image = CType(resources.GetObject("MonitorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MonitorToolStripMenuItem.Name = "MonitorToolStripMenuItem"
        Me.MonitorToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.MonitorToolStripMenuItem.Text = "Monitor"
        '
        'TurnOnToolStripMenuItem
        '
        Me.TurnOnToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.tick
        Me.TurnOnToolStripMenuItem.Name = "TurnOnToolStripMenuItem"
        Me.TurnOnToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.TurnOnToolStripMenuItem.Text = "Turn On"
        '
        'TurnOffToolStripMenuItem
        '
        Me.TurnOffToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.Delete_icon
        Me.TurnOffToolStripMenuItem.Name = "TurnOffToolStripMenuItem"
        Me.TurnOffToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.TurnOffToolStripMenuItem.Text = "Turn Off"
        '
        'MouseKeyboardToolStripMenuItem
        '
        Me.MouseKeyboardToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EnabledToolStripMenuItem, Me.DisabledToolStripMenuItem, Me.ToolStripSeparator8, Me.RigToolStripMenuItem})
        Me.MouseKeyboardToolStripMenuItem.Image = CType(resources.GetObject("MouseKeyboardToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MouseKeyboardToolStripMenuItem.Name = "MouseKeyboardToolStripMenuItem"
        Me.MouseKeyboardToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.MouseKeyboardToolStripMenuItem.Text = "Mouse | Keyboard"
        '
        'EnabledToolStripMenuItem
        '
        Me.EnabledToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.tick
        Me.EnabledToolStripMenuItem.Name = "EnabledToolStripMenuItem"
        Me.EnabledToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.EnabledToolStripMenuItem.Text = "Enable"
        '
        'DisabledToolStripMenuItem
        '
        Me.DisabledToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.Delete_icon
        Me.DisabledToolStripMenuItem.Name = "DisabledToolStripMenuItem"
        Me.DisabledToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.DisabledToolStripMenuItem.Text = "Disable"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(131, 6)
        '
        'RigToolStripMenuItem
        '
        Me.RigToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EnableToolStripMenuItem, Me.DisableToolStripMenuItem1})
        Me.RigToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.mouse_select_right_icon
        Me.RigToolStripMenuItem.Name = "RigToolStripMenuItem"
        Me.RigToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.RigToolStripMenuItem.Text = "Right Click"
        '
        'EnableToolStripMenuItem
        '
        Me.EnableToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.tick1
        Me.EnableToolStripMenuItem.Name = "EnableToolStripMenuItem"
        Me.EnableToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.EnableToolStripMenuItem.Text = "Enable"
        '
        'DisableToolStripMenuItem1
        '
        Me.DisableToolStripMenuItem1.Image = Global.Evil1._0a.My.Resources.Resources.Delete_icon
        Me.DisableToolStripMenuItem1.Name = "DisableToolStripMenuItem1"
        Me.DisableToolStripMenuItem1.Size = New System.Drawing.Size(119, 22)
        Me.DisableToolStripMenuItem1.Text = "Disable"
        '
        'DVDToolStripMenuItem
        '
        Me.DVDToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenDVDToolStripMenuItem, Me.CloseDVDToolStripMenuItem, Me.ToolStripSeparator7, Me.CrasyDVDToolStripMenuItem})
        Me.DVDToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.drive
        Me.DVDToolStripMenuItem.Name = "DVDToolStripMenuItem"
        Me.DVDToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DVDToolStripMenuItem.Text = "DVD Player"
        '
        'OpenDVDToolStripMenuItem
        '
        Me.OpenDVDToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.drive_cd
        Me.OpenDVDToolStripMenuItem.Name = "OpenDVDToolStripMenuItem"
        Me.OpenDVDToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.OpenDVDToolStripMenuItem.Text = "Open DVD"
        '
        'CloseDVDToolStripMenuItem
        '
        Me.CloseDVDToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.drive_cd_empty
        Me.CloseDVDToolStripMenuItem.Name = "CloseDVDToolStripMenuItem"
        Me.CloseDVDToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.CloseDVDToolStripMenuItem.Text = "Close DVD"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(133, 6)
        '
        'CrasyDVDToolStripMenuItem
        '
        Me.CrasyDVDToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.drive_error
        Me.CrasyDVDToolStripMenuItem.Name = "CrasyDVDToolStripMenuItem"
        Me.CrasyDVDToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.CrasyDVDToolStripMenuItem.Text = "Crasy DVD"
        '
        'CursorToolStripMenuItem
        '
        Me.CursorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowToolStripMenuItem1, Me.HideToolStripMenuItem1})
        Me.CursorToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.cursor_icon
        Me.CursorToolStripMenuItem.Name = "CursorToolStripMenuItem"
        Me.CursorToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.CursorToolStripMenuItem.Text = "Cursor"
        '
        'ShowToolStripMenuItem1
        '
        Me.ShowToolStripMenuItem1.Image = Global.Evil1._0a.My.Resources.Resources.emotion_wink
        Me.ShowToolStripMenuItem1.Name = "ShowToolStripMenuItem1"
        Me.ShowToolStripMenuItem1.Size = New System.Drawing.Size(111, 22)
        Me.ShowToolStripMenuItem1.Text = "Show"
        '
        'HideToolStripMenuItem1
        '
        Me.HideToolStripMenuItem1.Image = Global.Evil1._0a.My.Resources.Resources.emotion_suprised
        Me.HideToolStripMenuItem1.Name = "HideToolStripMenuItem1"
        Me.HideToolStripMenuItem1.Size = New System.Drawing.Size(111, 22)
        Me.HideToolStripMenuItem1.Text = "Hide"
        '
        'DesktopToolStripMenuItem
        '
        Me.DesktopToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TaskBarToolStripMenuItem})
        Me.DesktopToolStripMenuItem.Image = CType(resources.GetObject("DesktopToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DesktopToolStripMenuItem.Name = "DesktopToolStripMenuItem"
        Me.DesktopToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DesktopToolStripMenuItem.Text = "Desktop"
        '
        'TaskBarToolStripMenuItem
        '
        Me.TaskBarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HideToolStripMenuItem2, Me.EnableToolStripMenuItem1})
        Me.TaskBarToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.lightning
        Me.TaskBarToolStripMenuItem.Name = "TaskBarToolStripMenuItem"
        Me.TaskBarToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.TaskBarToolStripMenuItem.Text = "TaskBar"
        '
        'HideToolStripMenuItem2
        '
        Me.HideToolStripMenuItem2.Image = Global.Evil1._0a.My.Resources.Resources.emotion_suprised
        Me.HideToolStripMenuItem2.Name = "HideToolStripMenuItem2"
        Me.HideToolStripMenuItem2.Size = New System.Drawing.Size(111, 22)
        Me.HideToolStripMenuItem2.Text = "Hide"
        '
        'EnableToolStripMenuItem1
        '
        Me.EnableToolStripMenuItem1.Image = Global.Evil1._0a.My.Resources.Resources.emotion_wink
        Me.EnableToolStripMenuItem1.Name = "EnableToolStripMenuItem1"
        Me.EnableToolStripMenuItem1.Size = New System.Drawing.Size(111, 22)
        Me.EnableToolStripMenuItem1.Text = "Show"
        '
        'IEControlToolStripMenuItem
        '
        Me.IEControlToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangeHomePageToolStripMenuItem})
        Me.IEControlToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.IE_SZ_icon
        Me.IEControlToolStripMenuItem.Name = "IEControlToolStripMenuItem"
        Me.IEControlToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.IEControlToolStripMenuItem.Text = "IE Control"
        '
        'ChangeHomePageToolStripMenuItem
        '
        Me.ChangeHomePageToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.world_link
        Me.ChangeHomePageToolStripMenuItem.Name = "ChangeHomePageToolStripMenuItem"
        Me.ChangeHomePageToolStripMenuItem.Size = New System.Drawing.Size(179, 22)
        Me.ChangeHomePageToolStripMenuItem.Text = "Change Home Page"
        '
        'SoundToolStripMenuItem
        '
        Me.SoundToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MuteToolStripMenuItem})
        Me.SoundToolStripMenuItem.Image = CType(resources.GetObject("SoundToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SoundToolStripMenuItem.Name = "SoundToolStripMenuItem"
        Me.SoundToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SoundToolStripMenuItem.Text = "Sound"
        '
        'MuteToolStripMenuItem
        '
        Me.MuteToolStripMenuItem.Image = CType(resources.GetObject("MuteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MuteToolStripMenuItem.Name = "MuteToolStripMenuItem"
        Me.MuteToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.MuteToolStripMenuItem.Text = "Mute"
        '
        'SpeakToolStripMenuItem
        '
        Me.SpeakToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.emotion_tongue
        Me.SpeakToolStripMenuItem.Name = "SpeakToolStripMenuItem"
        Me.SpeakToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SpeakToolStripMenuItem.Text = "Speak"
        '
        'ChangeBackgroundToolStripMenuItem
        '
        Me.ChangeBackgroundToolStripMenuItem.Image = CType(resources.GetObject("ChangeBackgroundToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChangeBackgroundToolStripMenuItem.Name = "ChangeBackgroundToolStripMenuItem"
        Me.ChangeBackgroundToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ChangeBackgroundToolStripMenuItem.Text = "Change Background"
        '
        'OpenProgramToolStripMenuItem
        '
        Me.OpenProgramToolStripMenuItem.Image = CType(resources.GetObject("OpenProgramToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenProgramToolStripMenuItem.Name = "OpenProgramToolStripMenuItem"
        Me.OpenProgramToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.OpenProgramToolStripMenuItem.Text = "Open Program"
        '
        'OpenURLToolStripMenuItem
        '
        Me.OpenURLToolStripMenuItem.Image = CType(resources.GetObject("OpenURLToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenURLToolStripMenuItem.Name = "OpenURLToolStripMenuItem"
        Me.OpenURLToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.OpenURLToolStripMenuItem.Text = "Open URL"
        '
        'BlockWebSiteToolStripMenuItem
        '
        Me.BlockWebSiteToolStripMenuItem.Image = CType(resources.GetObject("BlockWebSiteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BlockWebSiteToolStripMenuItem.Name = "BlockWebSiteToolStripMenuItem"
        Me.BlockWebSiteToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.BlockWebSiteToolStripMenuItem.Text = "Block WebSite"
        '
        'CControlToolStripMenuItem2
        '
        Me.CControlToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShutdownToolStripMenuItem2, Me.RestartStripMenuItem2, Me.HibernationToolStripMenuItem2})
        Me.CControlToolStripMenuItem2.Image = Global.Evil1._0a.My.Resources.Resources.computer_icon1
        Me.CControlToolStripMenuItem2.Name = "CControlToolStripMenuItem2"
        Me.CControlToolStripMenuItem2.Size = New System.Drawing.Size(181, 22)
        Me.CControlToolStripMenuItem2.Text = "Computer Control"
        '
        'ShutdownToolStripMenuItem2
        '
        Me.ShutdownToolStripMenuItem2.Image = Global.Evil1._0a.My.Resources.Resources.computer_delete_icon
        Me.ShutdownToolStripMenuItem2.Name = "ShutdownToolStripMenuItem2"
        Me.ShutdownToolStripMenuItem2.Size = New System.Drawing.Size(133, 22)
        Me.ShutdownToolStripMenuItem2.Text = "Shutdown"
        '
        'RestartStripMenuItem2
        '
        Me.RestartStripMenuItem2.Image = Global.Evil1._0a.My.Resources.Resources.computer_go_icon
        Me.RestartStripMenuItem2.Name = "RestartStripMenuItem2"
        Me.RestartStripMenuItem2.Size = New System.Drawing.Size(133, 22)
        Me.RestartStripMenuItem2.Text = "Restart"
        '
        'HibernationToolStripMenuItem2
        '
        Me.HibernationToolStripMenuItem2.Image = Global.Evil1._0a.My.Resources.Resources.computer_error_icon
        Me.HibernationToolStripMenuItem2.Name = "HibernationToolStripMenuItem2"
        Me.HibernationToolStripMenuItem2.Size = New System.Drawing.Size(133, 22)
        Me.HibernationToolStripMenuItem2.Text = "Log Off"
        '
        'BSODToolStripMenuItem
        '
        Me.BSODToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.BSOD
        Me.BSODToolStripMenuItem.Name = "BSODToolStripMenuItem"
        Me.BSODToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.BSODToolStripMenuItem.Text = "BSOD"
        '
        'StealerToolStripMenuItem
        '
        Me.StealerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WindowsKeyToolStripMenuItem, Me.FpscKeyToolStripMenuItem, Me.MsnToolStripMenuItem, Me.NoIpToolStripMenuItem, Me.SteamToolStripMenuItem, Me.StealAllToolStripMenuItem})
        Me.StealerToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.lock_icon
        Me.StealerToolStripMenuItem.Name = "StealerToolStripMenuItem"
        Me.StealerToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.StealerToolStripMenuItem.Text = "Stealer"
        '
        'WindowsKeyToolStripMenuItem
        '
        Me.WindowsKeyToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.key_icon1
        Me.WindowsKeyToolStripMenuItem.Name = "WindowsKeyToolStripMenuItem"
        Me.WindowsKeyToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.WindowsKeyToolStripMenuItem.Text = "Windows Key"
        '
        'FpscKeyToolStripMenuItem
        '
        Me.FpscKeyToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.Viseur
        Me.FpscKeyToolStripMenuItem.Name = "FpscKeyToolStripMenuItem"
        Me.FpscKeyToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.FpscKeyToolStripMenuItem.Text = "Fps Creator Key"
        '
        'MsnToolStripMenuItem
        '
        Me.MsnToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.MSN_icon
        Me.MsnToolStripMenuItem.Name = "MsnToolStripMenuItem"
        Me.MsnToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.MsnToolStripMenuItem.Text = "Msn "
        '
        'NoIpToolStripMenuItem
        '
        Me.NoIpToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.ip_icon
        Me.NoIpToolStripMenuItem.Name = "NoIpToolStripMenuItem"
        Me.NoIpToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.NoIpToolStripMenuItem.Text = "No-Ip"
        '
        'SteamToolStripMenuItem
        '
        Me.SteamToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.steam_icon
        Me.SteamToolStripMenuItem.Name = "SteamToolStripMenuItem"
        Me.SteamToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.SteamToolStripMenuItem.Text = "Steam"
        '
        'StealAllToolStripMenuItem
        '
        Me.StealAllToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.floppy_icon
        Me.StealAllToolStripMenuItem.Name = "StealAllToolStripMenuItem"
        Me.StealAllToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.StealAllToolStripMenuItem.Text = "Steal All"
        '
        'RunVbsScriptToolStripMenuItem
        '
        Me.RunVbsScriptToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RunHtmlScriptToolStripMenuItem, Me.RunVbsScriptToolStripMenuItem1, Me.CleanScriptToolStripMenuItem})
        Me.RunVbsScriptToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.document_import_icon
        Me.RunVbsScriptToolStripMenuItem.Name = "RunVbsScriptToolStripMenuItem"
        Me.RunVbsScriptToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.RunVbsScriptToolStripMenuItem.Text = "Scripting"
        '
        'RunHtmlScriptToolStripMenuItem
        '
        Me.RunHtmlScriptToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.batch1
        Me.RunHtmlScriptToolStripMenuItem.Name = "RunHtmlScriptToolStripMenuItem"
        Me.RunHtmlScriptToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.RunHtmlScriptToolStripMenuItem.Text = "Run Batch Script"
        '
        'RunVbsScriptToolStripMenuItem1
        '
        Me.RunVbsScriptToolStripMenuItem1.Image = Global.Evil1._0a.My.Resources.Resources.vbs
        Me.RunVbsScriptToolStripMenuItem1.Name = "RunVbsScriptToolStripMenuItem1"
        Me.RunVbsScriptToolStripMenuItem1.Size = New System.Drawing.Size(164, 22)
        Me.RunVbsScriptToolStripMenuItem1.Text = "Run Vbs Script"
        '
        'CleanScriptToolStripMenuItem
        '
        Me.CleanScriptToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.bin_closed_icon
        Me.CleanScriptToolStripMenuItem.Name = "CleanScriptToolStripMenuItem"
        Me.CleanScriptToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.CleanScriptToolStripMenuItem.Text = "Clean Script "
        '
        'DisableProtectionToolStripMenuItem
        '
        Me.DisableProtectionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DisableCMDToolStripMenuItem, Me.DisableToolStripMenuItem, Me.DisableControlPanelToolStripMenuItem, Me.DisableRegistreToolStripMenuItem})
        Me.DisableProtectionToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.firewall_burn_icon
        Me.DisableProtectionToolStripMenuItem.Name = "DisableProtectionToolStripMenuItem"
        Me.DisableProtectionToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.DisableProtectionToolStripMenuItem.Text = "Disable Protection"
        '
        'DisableCMDToolStripMenuItem
        '
        Me.DisableCMDToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.cmd
        Me.DisableCMDToolStripMenuItem.Name = "DisableCMDToolStripMenuItem"
        Me.DisableCMDToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.DisableCMDToolStripMenuItem.Text = "Disable CMD"
        '
        'DisableToolStripMenuItem
        '
        Me.DisableToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.system_monitor_icon
        Me.DisableToolStripMenuItem.Name = "DisableToolStripMenuItem"
        Me.DisableToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.DisableToolStripMenuItem.Text = "Disable TaskManager"
        '
        'DisableControlPanelToolStripMenuItem
        '
        Me.DisableControlPanelToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.application_view_list_icon
        Me.DisableControlPanelToolStripMenuItem.Name = "DisableControlPanelToolStripMenuItem"
        Me.DisableControlPanelToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.DisableControlPanelToolStripMenuItem.Text = "Disable Control Panel"
        '
        'DisableRegistreToolStripMenuItem
        '
        Me.DisableRegistreToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.Misc_Database_3_icon
        Me.DisableRegistreToolStripMenuItem.Name = "DisableRegistreToolStripMenuItem"
        Me.DisableRegistreToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.DisableRegistreToolStripMenuItem.Text = "Disable Registry"
        '
        'WormFunctionsToolStripMenuItem
        '
        Me.WormFunctionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UsbSpreadToolStripMenuItem, Me.SkypeSpreadToolStripMenuItem})
        Me.WormFunctionsToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.bug
        Me.WormFunctionsToolStripMenuItem.Name = "WormFunctionsToolStripMenuItem"
        Me.WormFunctionsToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.WormFunctionsToolStripMenuItem.Text = "Worm Functions"
        '
        'UsbSpreadToolStripMenuItem
        '
        Me.UsbSpreadToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.usb_icon
        Me.UsbSpreadToolStripMenuItem.Name = "UsbSpreadToolStripMenuItem"
        Me.UsbSpreadToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.UsbSpreadToolStripMenuItem.Text = "Usb Spread"
        '
        'SkypeSpreadToolStripMenuItem
        '
        Me.SkypeSpreadToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.Apps_Skype_icon1
        Me.SkypeSpreadToolStripMenuItem.Name = "SkypeSpreadToolStripMenuItem"
        Me.SkypeSpreadToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.SkypeSpreadToolStripMenuItem.Text = "Skype Spread"
        '
        'DDOSToolStripMenuItem
        '
        Me.DDOSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HttpFlodoToolStripMenuItem, Me.GameFlodoToolStripMenuItem, Me.UDPFloodToolStripMenuItem, Me.SynFloodToolStripMenuItem, Me.IPGraberToolStripMenuItem})
        Me.DDOSToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_go_icon
        Me.DDOSToolStripMenuItem.Name = "DDOSToolStripMenuItem"
        Me.DDOSToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.DDOSToolStripMenuItem.Text = "DDOS"
        '
        'HttpFlodoToolStripMenuItem
        '
        Me.HttpFlodoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartFloodToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.HttpFlodoToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_connect_icon
        Me.HttpFlodoToolStripMenuItem.Name = "HttpFlodoToolStripMenuItem"
        Me.HttpFlodoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HttpFlodoToolStripMenuItem.Text = "HTTP Flood"
        '
        'StartFloodToolStripMenuItem
        '
        Me.StartFloodToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_add_icon
        Me.StartFloodToolStripMenuItem.Name = "StartFloodToolStripMenuItem"
        Me.StartFloodToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.StartFloodToolStripMenuItem.Text = "Start "
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_delete_icon
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.CloseToolStripMenuItem.Text = "Stop"
        '
        'GameFlodoToolStripMenuItem
        '
        Me.GameFlodoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem2, Me.StopToolStripMenuItem3, Me.PortToolStripMenuItem})
        Me.GameFlodoToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_save_icon
        Me.GameFlodoToolStripMenuItem.Name = "GameFlodoToolStripMenuItem"
        Me.GameFlodoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.GameFlodoToolStripMenuItem.Text = "Game Flood"
        '
        'StartToolStripMenuItem2
        '
        Me.StartToolStripMenuItem2.Image = Global.Evil1._0a.My.Resources.Resources.database_add_icon
        Me.StartToolStripMenuItem2.Name = "StartToolStripMenuItem2"
        Me.StartToolStripMenuItem2.Size = New System.Drawing.Size(112, 22)
        Me.StartToolStripMenuItem2.Text = "Start "
        '
        'StopToolStripMenuItem3
        '
        Me.StopToolStripMenuItem3.Image = Global.Evil1._0a.My.Resources.Resources.database_delete_icon
        Me.StopToolStripMenuItem3.Name = "StopToolStripMenuItem3"
        Me.StopToolStripMenuItem3.Size = New System.Drawing.Size(112, 22)
        Me.StopToolStripMenuItem3.Text = "Stop"
        '
        'PortToolStripMenuItem
        '
        Me.PortToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_gear_icon
        Me.PortToolStripMenuItem.Name = "PortToolStripMenuItem"
        Me.PortToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.PortToolStripMenuItem.Text = "Port"
        '
        'UDPFloodToolStripMenuItem
        '
        Me.UDPFloodToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem, Me.StopToolStripMenuItem})
        Me.UDPFloodToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_error_icon
        Me.UDPFloodToolStripMenuItem.Name = "UDPFloodToolStripMenuItem"
        Me.UDPFloodToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.UDPFloodToolStripMenuItem.Text = "UDP Flood"
        '
        'StartToolStripMenuItem
        '
        Me.StartToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_add_icon
        Me.StartToolStripMenuItem.Name = "StartToolStripMenuItem"
        Me.StartToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.StartToolStripMenuItem.Text = "Start"
        '
        'StopToolStripMenuItem
        '
        Me.StopToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_delete_icon
        Me.StopToolStripMenuItem.Name = "StopToolStripMenuItem"
        Me.StopToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.StopToolStripMenuItem.Text = "Stop"
        '
        'SynFloodToolStripMenuItem
        '
        Me.SynFloodToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem1, Me.StopToolStripMenuItem2})
        Me.SynFloodToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.database_lightning_icon
        Me.SynFloodToolStripMenuItem.Name = "SynFloodToolStripMenuItem"
        Me.SynFloodToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SynFloodToolStripMenuItem.Text = "Syn Flood"
        '
        'StartToolStripMenuItem1
        '
        Me.StartToolStripMenuItem1.Image = Global.Evil1._0a.My.Resources.Resources.database_add_icon
        Me.StartToolStripMenuItem1.Name = "StartToolStripMenuItem1"
        Me.StartToolStripMenuItem1.Size = New System.Drawing.Size(109, 22)
        Me.StartToolStripMenuItem1.Text = "Start"
        '
        'StopToolStripMenuItem2
        '
        Me.StopToolStripMenuItem2.Image = Global.Evil1._0a.My.Resources.Resources.database_delete_icon1
        Me.StopToolStripMenuItem2.Name = "StopToolStripMenuItem2"
        Me.StopToolStripMenuItem2.Size = New System.Drawing.Size(109, 22)
        Me.StopToolStripMenuItem2.Text = "Stop"
        '
        'IPGraberToolStripMenuItem
        '
        Me.IPGraberToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.transmit_icon
        Me.IPGraberToolStripMenuItem.Name = "IPGraberToolStripMenuItem"
        Me.IPGraberToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.IPGraberToolStripMenuItem.Text = "IP Grabber"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(218, 6)
        '
        'RemoteDownloadExecuteToolStripMenuItem
        '
        Me.RemoteDownloadExecuteToolStripMenuItem.Image = CType(resources.GetObject("RemoteDownloadExecuteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoteDownloadExecuteToolStripMenuItem.Name = "RemoteDownloadExecuteToolStripMenuItem"
        Me.RemoteDownloadExecuteToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.RemoteDownloadExecuteToolStripMenuItem.Text = "Remote Download \ Execute"
        '
        'CloseStripMenuItem2
        '
        Me.CloseStripMenuItem2.Image = CType(resources.GetObject("CloseStripMenuItem2.Image"), System.Drawing.Image)
        Me.CloseStripMenuItem2.Name = "CloseStripMenuItem2"
        Me.CloseStripMenuItem2.Size = New System.Drawing.Size(221, 22)
        Me.CloseStripMenuItem2.Text = "Close Server"
        '
        'DelStripMenuItem2
        '
        Me.DelStripMenuItem2.Image = CType(resources.GetObject("DelStripMenuItem2.Image"), System.Drawing.Image)
        Me.DelStripMenuItem2.Name = "DelStripMenuItem2"
        Me.DelStripMenuItem2.Size = New System.Drawing.Size(221, 22)
        Me.DelStripMenuItem2.Text = "Delete From The List"
        '
        'RfrshStripMenuItem2
        '
        Me.RfrshStripMenuItem2.Image = CType(resources.GetObject("RfrshStripMenuItem2.Image"), System.Drawing.Image)
        Me.RfrshStripMenuItem2.Name = "RfrshStripMenuItem2"
        Me.RfrshStripMenuItem2.Size = New System.Drawing.Size(221, 22)
        Me.RfrshStripMenuItem2.Text = "Refresh"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(218, 6)
        '
        'HideShowToolStripMenuItem
        '
        Me.HideShowToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IDToolStripMenuItem, Me.PCToolStripMenuItem, Me.WinToolStripMenuItem, Me.CountryToolStripMenuItem1, Me.CPUToolStripMenuItem, Me.IPToolStripMenuItem, Me.RAMStripMenuItem2, Me.VersionStripMenuItem2})
        Me.HideShowToolStripMenuItem.Image = CType(resources.GetObject("HideShowToolStripMenuItem.Image"), System.Drawing.Image)
        Me.HideShowToolStripMenuItem.Name = "HideShowToolStripMenuItem"
        Me.HideShowToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.HideShowToolStripMenuItem.Text = "Hide/Show"
        '
        'IDToolStripMenuItem
        '
        Me.IDToolStripMenuItem.Checked = True
        Me.IDToolStripMenuItem.CheckOnClick = True
        Me.IDToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IDToolStripMenuItem.Name = "IDToolStripMenuItem"
        Me.IDToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.IDToolStripMenuItem.Text = "ID"
        '
        'PCToolStripMenuItem
        '
        Me.PCToolStripMenuItem.Checked = True
        Me.PCToolStripMenuItem.CheckOnClick = True
        Me.PCToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.PCToolStripMenuItem.Name = "PCToolStripMenuItem"
        Me.PCToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.PCToolStripMenuItem.Text = "PC"
        '
        'WinToolStripMenuItem
        '
        Me.WinToolStripMenuItem.Checked = True
        Me.WinToolStripMenuItem.CheckOnClick = True
        Me.WinToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.WinToolStripMenuItem.Name = "WinToolStripMenuItem"
        Me.WinToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.WinToolStripMenuItem.Text = "Windows"
        '
        'CountryToolStripMenuItem1
        '
        Me.CountryToolStripMenuItem1.Checked = True
        Me.CountryToolStripMenuItem1.CheckOnClick = True
        Me.CountryToolStripMenuItem1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CountryToolStripMenuItem1.Name = "CountryToolStripMenuItem1"
        Me.CountryToolStripMenuItem1.Size = New System.Drawing.Size(128, 22)
        Me.CountryToolStripMenuItem1.Text = "Country"
        '
        'CPUToolStripMenuItem
        '
        Me.CPUToolStripMenuItem.Checked = True
        Me.CPUToolStripMenuItem.CheckOnClick = True
        Me.CPUToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CPUToolStripMenuItem.Name = "CPUToolStripMenuItem"
        Me.CPUToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.CPUToolStripMenuItem.Text = "CPU"
        '
        'IPToolStripMenuItem
        '
        Me.IPToolStripMenuItem.Checked = True
        Me.IPToolStripMenuItem.CheckOnClick = True
        Me.IPToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IPToolStripMenuItem.Name = "IPToolStripMenuItem"
        Me.IPToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.IPToolStripMenuItem.Text = "IP"
        '
        'RAMStripMenuItem2
        '
        Me.RAMStripMenuItem2.Checked = True
        Me.RAMStripMenuItem2.CheckOnClick = True
        Me.RAMStripMenuItem2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.RAMStripMenuItem2.Name = "RAMStripMenuItem2"
        Me.RAMStripMenuItem2.Size = New System.Drawing.Size(128, 22)
        Me.RAMStripMenuItem2.Text = "RAM"
        '
        'VersionStripMenuItem2
        '
        Me.VersionStripMenuItem2.Checked = True
        Me.VersionStripMenuItem2.CheckOnClick = True
        Me.VersionStripMenuItem2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.VersionStripMenuItem2.Name = "VersionStripMenuItem2"
        Me.VersionStripMenuItem2.Size = New System.Drawing.Size(128, 22)
        Me.VersionStripMenuItem2.Text = "Version"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FilesToolStripMenuItem, Me.ConnectionToolStripMenuItem, Me.ExitToolStripMenuItem2})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(747, 24)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FilesToolStripMenuItem
        '
        Me.FilesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BuilderToolStripMenuItem, Me.ToolStripSeparator4, Me.SettingsToolStripMenuItem, Me.ToolStripSeparator3, Me.NoIpUpdateToolStripMenuItem, Me.ToolStripSeparator5, Me.ExitToolStripMenuItem})
        Me.FilesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.FilesToolStripMenuItem.Name = "FilesToolStripMenuItem"
        Me.FilesToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.FilesToolStripMenuItem.Text = "Files"
        '
        'BuilderToolStripMenuItem
        '
        Me.BuilderToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.make_icon
        Me.BuilderToolStripMenuItem.Name = "BuilderToolStripMenuItem"
        Me.BuilderToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.BuilderToolStripMenuItem.Text = "Builder"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(147, 6)
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.Misc_Settings_icon
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(147, 6)
        '
        'NoIpUpdateToolStripMenuItem
        '
        Me.NoIpUpdateToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.icon
        Me.NoIpUpdateToolStripMenuItem.Name = "NoIpUpdateToolStripMenuItem"
        Me.NoIpUpdateToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.NoIpUpdateToolStripMenuItem.Text = "No-IP Update"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(147, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Image = CType(resources.GetObject("ExitToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ConnectionToolStripMenuItem
        '
        Me.ConnectionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListenToolStripMenuItem1, Me.ToolStripSeparator2, Me.StopToolStripMenuItem1})
        Me.ConnectionToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.ConnectionToolStripMenuItem.Name = "ConnectionToolStripMenuItem"
        Me.ConnectionToolStripMenuItem.Size = New System.Drawing.Size(73, 20)
        Me.ConnectionToolStripMenuItem.Text = "Connection"
        '
        'ListenToolStripMenuItem1
        '
        Me.ListenToolStripMenuItem1.Image = Global.Evil1._0a.My.Resources.Resources.socket_plus_icon
        Me.ListenToolStripMenuItem1.Name = "ListenToolStripMenuItem1"
        Me.ListenToolStripMenuItem1.Size = New System.Drawing.Size(113, 22)
        Me.ListenToolStripMenuItem1.Text = "Listen"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(110, 6)
        '
        'StopToolStripMenuItem1
        '
        Me.StopToolStripMenuItem1.Image = Global.Evil1._0a.My.Resources.Resources.socket_minus_icon
        Me.StopToolStripMenuItem1.Name = "StopToolStripMenuItem1"
        Me.StopToolStripMenuItem1.Size = New System.Drawing.Size(113, 22)
        Me.StopToolStripMenuItem1.Text = "Stop"
        '
        'ExitToolStripMenuItem2
        '
        Me.ExitToolStripMenuItem2.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.ExitToolStripMenuItem2.Name = "ExitToolStripMenuItem2"
        Me.ExitToolStripMenuItem2.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem2.Text = "Exit"
        '
        'lstClients
        '
        Me.lstClients.BackColor = System.Drawing.Color.White
        Me.lstClients.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader9})
        Me.lstClients.ContextMenuStrip = Me.ContextMenuStrip1
        Me.lstClients.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstClients.ForeColor = System.Drawing.Color.White
        Me.lstClients.Location = New System.Drawing.Point(0, 24)
        Me.lstClients.Name = "lstClients"
        Me.lstClients.Size = New System.Drawing.Size(747, 289)
        Me.lstClients.SmallImageList = Me.ImageList1
        Me.lstClients.TabIndex = 5
        Me.lstClients.UseCompatibleStateImageBehavior = False
        Me.lstClients.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        Me.ColumnHeader1.Width = 77
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "PC"
        Me.ColumnHeader2.Width = 124
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Windows"
        Me.ColumnHeader3.Width = 195
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Country"
        Me.ColumnHeader4.Width = 105
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "CPU"
        Me.ColumnHeader5.Width = 77
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "IP"
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "RAM"
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Version"
        Me.ColumnHeader9.Width = 71
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "User.png")
        '
        'notify
        '
        Me.notify.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.notify.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel2})
        Me.notify.Location = New System.Drawing.Point(0, 291)
        Me.notify.MaximumSize = New System.Drawing.Size(747, 22)
        Me.notify.MinimumSize = New System.Drawing.Size(747, 22)
        Me.notify.Name = "notify"
        Me.notify.Size = New System.Drawing.Size(747, 22)
        Me.notify.TabIndex = 18
        Me.notify.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel1.Image = CType(resources.GetObject("ToolStripStatusLabel1.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(95, 17)
        Me.ToolStripStatusLabel1.Text = "Status : Ready"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel3.Image = CType(resources.GetObject("ToolStripStatusLabel3.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(69, 17)
        Me.ToolStripStatusLabel3.Text = "Online : 0"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(439, 17)
        Me.ToolStripStatusLabel2.Text = "         Status:                                                                 " & _
            "                                                         -"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(374, 104)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Label1"
        Me.Label1.Visible = False
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.ContextMenuStrip = Me.ContextMenuStrip2
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "BlackNess"
        Me.NotifyIcon1.Visible = True
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowToolStripMenuItem, Me.HideToolStripMenuItem, Me.ToolStripSeparator6, Me.ExitToolStripMenuItem1})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(112, 76)
        '
        'ShowToolStripMenuItem
        '
        Me.ShowToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.application_add_icon
        Me.ShowToolStripMenuItem.Name = "ShowToolStripMenuItem"
        Me.ShowToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.ShowToolStripMenuItem.Text = "Show"
        '
        'HideToolStripMenuItem
        '
        Me.HideToolStripMenuItem.Image = Global.Evil1._0a.My.Resources.Resources.application_delete_icon
        Me.HideToolStripMenuItem.Name = "HideToolStripMenuItem"
        Me.HideToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.HideToolStripMenuItem.Text = "Hide"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(108, 6)
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Image = CType(resources.GetObject("ExitToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(111, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'SkinCrafter1
        '
        Me.SkinCrafter1.SkinFile = "Skin.skf"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.Control
        Me.PictureBox1.Location = New System.Drawing.Point(125, 336)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(510, 152)
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(747, 313)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.notify)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lstClients)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximumSize = New System.Drawing.Size(755, 341)
        Me.MinimumSize = New System.Drawing.Size(755, 341)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "BlackNess v1.6"
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.notify.ResumeLayout(False)
        Me.notify.PerformLayout()
        Me.ContextMenuStrip2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ComputerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FunnyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RemoteDownloadExecuteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FilesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConnectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListenToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DelStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RfrshStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents lstClients As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ComputerInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TraceIPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProcessManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FakeMessageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MonitorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TurnOnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TurnOffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MouseKeyboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnabledToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisabledToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DesktopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SoundToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MuteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeBackgroundToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BuilderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents notify As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents OpenProgramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenURLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents BlockWebSiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HideShowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WinToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CountryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CPUToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RAMStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VersionStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CControlToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShutdownToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HibernationToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BSODToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DisableProtectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableCMDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableControlPanelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RigToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskBarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnableToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HideToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WormFunctionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UsbSpreadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DVDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenDVDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseDVDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableRegistreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CrasyDVDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SpeakToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CloseProcessusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartProcessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IEControlToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeHomePageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SkypeSpreadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents NoIpUpdateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents StealerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WindowsKeyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FpscKeyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ShowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HideToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents RunVbsScriptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RunHtmlScriptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RunVbsScriptToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CleanScriptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DDOSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HttpFlodoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartFloodToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UDPFloodToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IPGraberToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SynFloodToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SkinCrafter1 As DMSoft.SkinCrafter
    Friend WithEvents GetAntivirusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SteamToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StealAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GameFlodoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PortToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CursorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShowToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HideToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NoIpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MsnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class

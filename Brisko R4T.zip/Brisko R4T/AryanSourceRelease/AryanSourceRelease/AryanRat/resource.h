//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU2                       104
#define IDD_DIALOG2                     110
#define IDD_DIALOG3                     111
#define IDR_MENU1                       114
#define IDB_TREE                        132
#define IDB_FILE                        133
#define IDR_MENU3                       134
#define IDD_FILE                        135
#define IDB_FLOPPY                      139
#define IDB_CD                          141
#define IDB_STATIC                      143
#define IDB_NETWORK                     145
#define IDB_FOLDER                      149
#define IDB_BACK                        153
#define IDR_TOOLBAR1                    172
#define IDR_COMMANDS                    174
#define IDR_MENU4                       175
#define IDR_MENUFolder                  177
#define IDB_BOOKMARK                    179
#define IDR_MENUBOOK                    181
#define IDI_BOOKMARKRED                 192
#define IDI_BOOKMARKBLUE                193
#define IDI_BOOKMARK                    194
#define IDI_BOOKMARKPURPLE              195
#define IDC_TASK_TAB                    200
#define IDI_STATIC                      227
#define IDI_FILE                        233
#define IDI_TEXT                        236
#define IDI_MEDIA                       237
#define IDI_EXE                         243
#define IDI_FOLDER                      246
#define IDI_FLOPPY                      247
#define IDI_CD                          248
#define IDI_NETWORK                     249
#define IDI_PICTURE                     250
#define IDI_VIDEO                       251
#define IDI_COMPRESSED                  253
#define IDD_RENAME                      259
#define IDR_DOWNLOAD                    260
#define IDC_FILE_STATUS                 1011
#define IDC_TASK_STATUS                 1012
#define IDC_MAIN_STATUS                 1013
#define IDC_SERVERLIST                  1014
#define IDC_LOGS                        1015
#define IDC_CONNECTIONSTATUS            1017
#define IDC_COMMANDS                    1019
#define IDC_SENDCMD                     1020
#define IDC_SHELL_STATUS                1021
#define IDC_TASKLIST                    1021
#define IDC_Windows                     1022
#define IDC_LISTDIR                     1036
#define IDC_TREE1                       1037
#define IDC_FILELIST                    1038
#define IDC_BOOKMARKS                   1039
#define IDC_FOLDERS                     1041
#define IDC_DOWNLOADS                   1043
#define IDC_TAB1                        1044
#define IDC_NAME                        1057
#define IDC_SETNAME                     1058
#define IDC_LISTEN                      40001
#define IDC_DISCONNECT                  40002
#define IDC_EXIT                        40003
#define IDC_RESET                       40004
#define IDC_FILEMANAGER                 40005
#define IDC_SHELL                       40006
#define IDC_TASKMANAGER                 40007
#define IDC_CONNECTIONOPTIONS           40008
#define IDC_EDITSERVER                  40009
#define IDC_TASK_KILL                   40011
#define IDC_REFRESH_TASK                40012
#define IDC_FOLDER                      40013
#define IDC_DELETE                      40014
#define IDC_DELETEFILE                  40014
#define IDC_BACK                        40015
#define IDC_FORWARD                     40016
#define ID_BUTTON40017                  40017
#define IDC_LOGOFF                      40018
#define IDC_SHUTDOWN                    40019
#define IDC_RESTART                     40020
#define IDC_BOOKMARK                    40026
#define IDC_ENTERDIR                    40027
#define IDC_DOWNLOADFILE                40028
#define IDC_UPLOAD                      40029
#define IDC_GOTO                        40030
#define IDC_ADDBOOKMARK                 40031
#define IDC_COPY                        40033
#define IDC_PASTE                       40034
#define IDC_MOVE                        40037
#define IDC_RENAME                      40038
#define IDC_NEW_FOLDER                  40039
#define IDC_RENAME_FOLDER               40040

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        261
#define _APS_NEXT_COMMAND_VALUE         40041
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

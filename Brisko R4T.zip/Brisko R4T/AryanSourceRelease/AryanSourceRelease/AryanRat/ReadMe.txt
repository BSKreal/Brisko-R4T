============================================================
===============http://mint-community.org====================

Name: Aryan RAT base source code release.
Date: 18/1/2009
Author: AlbinoSkunk.
Contact MSN: Albinoskunk101@hotmail.com
Website: Mint-commmunity.org
IRC: Mint-community.org #mint or 173.45.69.26 #mint
Language/compiler: MSVC 6.0 

Thanks to BinaryHero for testing and giving me
a few pointers aswell as bug reporting <3.

Thanks to Krippler for taking sometime out to help me
with a few bugs i come across and also for the isadmin function.

Reason for releasing: i feel that in the RAT programming scene there are very little to none, non-MFC MSVC RAT's out there which are opensource,
so i felt that i should make a base that other's who are finding it hard to find any examples a head start, this is the only release that i am going opensource
but i will probably continue to release snippets but this will be the only 1/2 project that i will release, some features have been left out because
i have either not compeleted or have already released source code for that feature.

Note: there are some bugs still in both the client and the server, i have left these there for other's to develop
ontop of and hopefully in doing so learn, so please do not contact me with bugs in the source, but you are more than welcome to use the contact info (MSN/IRC)
to ask me questions/help.

if you choose to use my source i would be greatful if you gave credits to me and the above site and people.

-Albinoskunk.
